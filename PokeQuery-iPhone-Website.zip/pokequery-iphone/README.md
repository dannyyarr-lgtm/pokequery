# PokeQuery RPG — iPhone-ready website

This is a single-page SQL learning RPG. It retains the existing SQL lesson library and practice engine, and adds:

- Wild Pokémon encounters with animated Poké Ball capture sequences
- SQL-checked encounters: you must write a correct query to register a Pokémon
- 12 sequential Gym Leader boss battles, each with a SQL challenge, badge, XP and Pokémon reward
- Six region unlocks, opening after every two Gym Badges
- Topic mastery tracking for filtering, aggregation, joins, subqueries, CASE logic and capstone SQL
- A Pokédex view and locally saved progress

## Publish for iPhone

1. Create a GitHub repository named `pokequery`.
2. Upload `index.html` to the repository root and commit it.
3. Open **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
5. When GitHub Pages finishes publishing, open `https://YOUR-USERNAME.github.io/pokequery/` in Safari.
6. In Safari, tap **Share → Add to Home Screen** to use it like an app.

The SQL engine is currently loaded from the Alasql CDN, so an internet connection is needed. Progress is saved in that browser's local storage and does not automatically sync across devices. Test the published version before relying on it; this package has not been deployed to a public URL.
